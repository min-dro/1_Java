module TIcTacToe {
	requires java.rmi;
}