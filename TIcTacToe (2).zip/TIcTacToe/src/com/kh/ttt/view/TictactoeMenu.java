package com.kh.ttt.view;

import java.util.Scanner;

import com.kh.ttt.gameController.TictactoeController;
import com.kh.ttt.model.vo.Users;

public class TictactoeMenu {
	Users u = new Users();
	TictactoeController tc = new TictactoeController();
	private Scanner sc = new Scanner(System.in);

	public void Mainmenu() {
		while (true) {
			System.out.println("===== 틱택토 =====");
			System.out.println("1. 시작");
			System.out.println("2. 닉네임 변경");
			System.out.println("3. 점수표");
			System.out.println("0. 종료");
			System.out.print("입력 : ");
			int num = sc.nextInt();
			switch (num) {
			case 1:
				Gameselect();
				break;
			case 2:
				Nicknamechange();
				break;
			case 3:
				tc.Score();
				break;
			case 0:
				System.out.println("프로그램을 종료합니다.");
				return;
			default:
				System.out.println("잘못입력하셨습니다. 다시입력해주세요.");
			}
		}
	}

	public void Gameselect() {
		while (true) {
			System.out.println("어떻게 플레이 하시겠습니까?");
			System.out.println("1. 1:1 대결");
			System.out.println("2. 혼자놀기(점수는 증가하지 않음)");
			System.out.println("3. 1:1 온라인 매칭");
			System.out.println("0. 메인메뉴로");
			System.out.print("입력 : ");
			int num = sc.nextInt();
			switch (num) {
			case 1:
				tc.TicTactoe();
				break;
			case 2:
				Hitoryready();
				break;
			case 3:
				Onlineready();
				break;
			case 0:
				return;
			default:
				System.out.println("잘못입력하셨습니다. 다시입력해주세요.");
			}
		}
	}

	public void Hitoryready() {
		while (true) {
			System.out.println("누구로 플레이하시겠습니까?");
			System.out.println("1. " + tc.User1name());
			System.out.println("2. " + tc.User2name());
			System.out.println("0. 뒤로가기");
			int num = sc.nextInt();
			switch (num) {
			case 1:
			case 2:
				tc.UservsCom(num);
				break;
			case 0:
				return;
			default:
				System.out.println("잘못입력하셨습니다. 다시입력해주세요.");
			}
		}
	}

	public void Onlineready() {
		while (true) {
			System.out.println("누구로 플레이하시겠습니까?");
			System.out.println("1. " + tc.User1name());
			System.out.println("2. " + tc.User2name());
			System.out.println("0. 뒤로가기");
			int num = sc.nextInt();
			switch (num) {
			case 1:
				tc.OnlineMatching(num);
			case 2:
				tc.OnlineMatching(num);
				break;
			case 0:
				return;
			default:
				System.out.println("잘못입력하셨습니다. 다시입력해주세요.");
			}
		}
	}

	public void Nicknamechange() {
		while (true) {
			System.out.println("어떤 유저의 닉네임을 변경하시겠습니까?");
			System.out.println("1. " + tc.User1name());
			System.out.println("2. " + tc.User2name());
			System.out.println("0. 메인메뉴로");
			System.out.print("입력 : ");
			int num = sc.nextInt();
			switch (num) {
			case 1:
			case 2:
				Changename(num);
				break;
			case 0:
				return;
			default:
				System.out.println("잘못입력하셨습니다. 다시입력해주세요.");
			}
		}
	}

	public void Changename(int num) {
		System.out.print("변경하실 닉네임을 입력하세요 : ");
		if (num == 1) {
			String user1 = sc.next();
			tc.Changename1(user1);
		} else if (num == 2) {
			String user2 = sc.next();
			tc.Changename2(user2);
		}
		System.out.println("닉네임변경이 완료 되었습니다!");
	}
}
