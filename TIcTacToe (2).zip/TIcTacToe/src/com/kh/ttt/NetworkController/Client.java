package com.kh.ttt.NetworkController;

import com.kh.ttt.gameController.TictactoeController;
import com.kh.ttt.model.vo.Users;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.rmi.UnknownHostException;
import java.util.Scanner;

public class Client {

	public void Main() {

		Scanner sc = new Scanner(System.in);
		Users u = new Users();
		TictactoeController tc = new TictactoeController();
		// 1) 요청할 서버의 "IP 주소", "포트 번호" 확인.
		String serverIP = "192.168.10.17";
		int port = 3000;

		// 사용되는 통로(소캣, 스트림) 초기화
		Socket socket = null;
		BufferedReader br = null;
		PrintWriter pw = null;

		// 2) 서버에 연결 요청을 보내기 ( 요청하고자 하는 서버의 IP주소와 포트번호를 사용하여 소켓 객체 생성 )
		try {
			socket = new Socket(serverIP, port);
			System.out.println("매칭중...");
			if (socket != null) { // 서버와의 연결 성공했을 경우
				System.out.println("매칭성공!");
				System.out.println("  0 1 2");
				System.out.println("0");
				System.out.println("1");
				System.out.println("2");

				// 3) 서버와 입출력 기반스트림 생성
				// 4) 보조스트림을 통해서 성능 개선
				br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

				// 출력용 스트림
				pw = new PrintWriter(socket.getOutputStream());
				int count = 0;
				int userScore1 = u.getScore1();
				int userScore2 = u.getScore2();
				// 5) 스트림 사용하여 입출력(데이터 통신)
				while (true) {
					if (count % 2 == 0) {
						System.out.println(u.getUser1() + "님의 차례입니다.");
					} else if (count % 2 == 1) {
						System.out.println(u.getUser2() + "님의 차례입니다.");
						while (true) {
							System.out.print("가로 값을 입력하세요 : ");
							tc.length = sc.nextInt();
							System.out.print("세로 값을 입력하세요 : ");
							tc.width = sc.nextInt();
							if ((tc.length != 2 && tc.length != 1 && tc.length != 0)
									|| (tc.width != 2 && tc.width != 1 && tc.width != 0)) {
								System.out.println("원하는 값이 아닙니다. 다시입력해주세요.");
							} else if (tc.frame[tc.width + 1][tc.length + 1] == 'X'
									|| tc.frame[tc.width + 1][tc.length + 1] == 'O') {
								System.out.println("해당 값에 이미 입력한 값이 있습니다. 다시입력해주세요.");
							} else {
								break;
							}
						}

						// 출력 - 서버측으로 데이터 전송
						char x = '0';
						char y = '0';
						tc.width += 1;
						tc.length += 1;
						for (int i = 0; i < tc.frame.length; i++) {
							for (int j = 0; j < tc.frame.length; j++) {
								if (i == 0 && j == 0) {
									System.out.print("");
								} else if (i == 0 || j == 0) {
									if (j == 0) {
										tc.frame[i][j] = (char) x++;
									} else {
										tc.frame[i][j] = (char) y++;
									}
								} else if (i == tc.width && j == tc.length) {
									if (count % 2 == 0)
										tc.frame[i][j] = 'X';
									else if (count % 2 == 1)
										tc.frame[i][j] = 'O';
								} else {
									System.out.print("");
								}
								System.out.print(tc.frame[i][j] + " ");
							}
							System.out.println();
						}
					}
					count++;
					pw.println(tc.frame[0][0]+" "+tc.frame[0][1]+" "+tc.frame[0][2]+" "+tc.frame[0][3]+"\n"+
							tc.frame[1][0]+" "+tc.frame[1][1]+" "+tc.frame[1][2]+" "+tc.frame[1][3]+"\n"+
							tc.frame[2][0]+" "+tc.frame[2][1]+" "+tc.frame[2][2]+" "+tc.frame[2][3]+"\n"+
							tc.frame[3][0]+" "+tc.frame[3][1]+" "+tc.frame[3][2]+" "+tc.frame[3][3]);	
					pw.flush(); // 입력하지 않으면 데이터가 전달되지 않을 수 있어 사용

					// 입력 - 서버로부터 데이터를 전달 받음
					
					String message = br.readLine();
					System.out.println(message);
				}
			}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pw != null)
					pw.close();
				if (br != null)
					br.close();
			} catch (IOException e) {
			}
		}
	}
}
