package com.kh.ttt.model.vo;

public class Users {
	private String user1 = "User1";
	private String user2 = "User2";
	private int score1 = 0;
	private int score2 = 0;
	public Users() {}
	public Users(String user1, String user2, int score1, int score2) {
		this.user1 = user1;
		this.user2 = user2;
		this.score1 = score1;
		this.score2 = score2;
	}
	public String getUser1() {
		return user1;
	}
	public void setUser1(String user1) {
		this.user1 = user1;
	}
	public String getUser2() {
		return user2;
	}
	public void setUser2(String user2) {
		this.user2 = user2;
	}
	public int getScore1() {
		return score1;
	}
	public void setScore1(int score1) {
		this.score1 = score1;
	}
	public int getScore2() {
		return score2;
	}
	public void setScore2(int score2) {
		this.score2 = score2;
	}
	public String toString() {
		return String.format("%s : %d, %s : %d", user1, score1, user2, score2);
	}
}	
