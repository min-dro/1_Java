package com.kh.ttt.model.dao;

public class TictactoeDao {

}
