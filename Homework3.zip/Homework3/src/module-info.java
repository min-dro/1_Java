module Homework3 {
}